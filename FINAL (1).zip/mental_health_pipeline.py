"""End-to-end pipeline for profiling student mental-health risk groups."""

import argparse
import json
import logging
from pathlib import Path
import re
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.metrics import classification_report, confusion_matrix, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier
from scipy import stats

try:
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "PyTorch is required for the autoencoder. Please install it with 'pip install torch' and rerun the script."  # noqa: E501
    ) from exc


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)

AUTOENCODER_EPOCHS = 60
AUTOENCODER_BATCH_SIZE = 64
AUTOENCODER_LR = 1e-3
CLUSTER_MIN = 2
CLUSTER_MAX = 6
RF_PARAMS = {"n_estimators": 200, "random_state": RANDOM_STATE, "class_weight": "balanced"}


class Autoencoder(nn.Module):
    """Simple feed-forward autoencoder used to learn dense student embeddings."""

    def __init__(self, input_dim: int, embedding_dim: int) -> None:
        super().__init__()
        hidden_dim = max(embedding_dim * 4, 16)
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, embedding_dim),
        )
        self.decoder = nn.Sequential(
            nn.Linear(embedding_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encoder(x)
        return self.decoder(z)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        return self.encoder(x)


def load_datasets(paths: List[Path]) -> pd.DataFrame:
    """Load multiple CSV files into a single DataFrame while logging progress."""
    frames = []
    for path in paths:
        if not path.exists():
            logging.warning("File not found: %s", path)
            continue
        logging.info("Loading %s", path.name)
        frames.append(pd.read_csv(path))
    if not frames:
        raise FileNotFoundError("No valid CSV files were provided.")
    combined = pd.concat(frames, ignore_index=True)
    logging.info("Loaded %d records", combined.shape[0])
    return combined


def _standardize_string(value: str) -> str:
    """Normalize strings by trimming whitespace, lowercasing, and collapsing spaces."""
    if pd.isna(value):
        return np.nan
    return re.sub(r"\s+", " ", str(value).strip().lower())


def _map_year(value: str) -> float:
    """Extract numeric year value from free-text survey responses."""
    if pd.isna(value):
        return np.nan
    cleaned = _standardize_string(value)
    match = re.search(r"(\d)", cleaned)
    if match:
        return float(match.group(1))
    return np.nan


def _map_cgpa(value: str) -> float:
    """Convert CGPA ranges such as '3.5-4.0' to their midpoint numeric value."""
    if pd.isna(value):
        return np.nan
    cleaned = str(value).replace(" ", "")
    range_match = re.match(r"(\d+(?:\.\d+)?)[-](\d+(?:\.\d+)?)", cleaned)
    if range_match:
        low, high = range_match.groups()
        return (float(low) + float(high)) / 2.0
    try:
        return float(cleaned)
    except ValueError:
        return np.nan


def preprocess_raw(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Clean incoming survey data and return both processed features and a cleaned copy."""
    column_map = {
        "Choose your gender": "gender",
        "Age": "age",
        "What is your course?": "course",
        "Your current year of Study": "year",
        "What is your CGPA?": "cgpa_range",
        "Marital status": "marital_status",
        "Do you have Depression?": "depression",
        "Do you have Anxiety?": "anxiety",
        "Do you have Panic attack?": "panic",
        "Did you seek any specialist for a treatment?": "specialist",
    }
    df = df.rename(columns=column_map)
    base_columns = list(column_map.values())
    missing_columns = [col for col in base_columns if col not in df.columns]
    if missing_columns:
        raise ValueError(f"Dataset missing required columns: {missing_columns}")
    df = df[base_columns].copy()

    for col in ["gender", "course", "marital_status", "year", "cgpa_range"]:
        df[col] = df[col].apply(_standardize_string)

    df["year_numeric"] = df["year"].apply(_map_year)
    df["cgpa_numeric"] = df["cgpa_range"].apply(_map_cgpa)

    binary_cols = ["depression", "anxiety", "panic", "specialist"]
    for col in binary_cols:
        df[col] = df[col].apply(lambda x: 1 if _standardize_string(x) == "yes" else 0)

    df["gender"] = df["gender"].replace({"male": "Male", "female": "Female"})
    df.loc[~df["gender"].isin(["Male", "Female"]), "gender"] = "Other"
    df["course"] = df["course"].apply(lambda x: np.nan if pd.isna(x) else x.title())
    df["marital_status"] = df["marital_status"].apply(lambda x: np.nan if pd.isna(x) else x.title())

    df["age"] = pd.to_numeric(df["age"], errors="coerce")

    cleaned = df.copy()

    # Fill numeric holes with medians to keep scale intact without skewing distributions.
    for col in ["age", "year_numeric", "cgpa_numeric"]:
        df[col] = df[col].fillna(df[col].median())
    cat_fill_columns = ["gender", "course", "marital_status"]
    # Replace missing categorical entries with mode to retain categorical balance.
    for col in cat_fill_columns:
        df[col] = df[col].fillna(df[col].mode().iloc[0])

    features = df[[
        "age",
        "year_numeric",
        "cgpa_numeric",
        "gender",
        "course",
        "marital_status",
        "depression",
        "anxiety",
        "panic",
        "specialist",
    ]].copy()
    numeric_features = ["age", "year_numeric", "cgpa_numeric"]
    categorical_features = ["gender", "course", "marital_status"]

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_features),
            (
                "cat",
                OneHotEncoder(handle_unknown="ignore"),
                categorical_features,
            ),
        ],
        remainder="passthrough",
    )

    pipeline = Pipeline([("prep", preprocessor)])
    prepared = pipeline.fit_transform(features)
    if hasattr(prepared, "toarray"):
        prepared = prepared.toarray()
    cat_names = pipeline.named_steps["prep"].named_transformers_["cat"].get_feature_names_out(categorical_features)
    all_columns = numeric_features + list(cat_names) + [
        "depression",
        "anxiety",
        "panic",
        "specialist",
    ]
    processed_df = pd.DataFrame(prepared, columns=all_columns, index=df.index)
    processed_df[["depression", "anxiety", "panic", "specialist"]] = processed_df[[
        "depression",
        "anxiety",
        "panic",
        "specialist",
    ]].astype(int)

    return processed_df, cleaned


def train_autoencoder(
    features: pd.DataFrame,
    embedding_dim: int = 8,
    epochs: int = AUTOENCODER_EPOCHS,
    batch_size: int = AUTOENCODER_BATCH_SIZE,
    lr: float = AUTOENCODER_LR,
) -> Tuple[Autoencoder, np.ndarray]:
    """Train an autoencoder on processed features and return embeddings."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    input_dim = features.shape[1]
    model = Autoencoder(input_dim=input_dim, embedding_dim=embedding_dim).to(device)
    optimiser = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.MSELoss()

    dataset = TensorDataset(torch.tensor(features.values, dtype=torch.float32))
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    model.train()
    for epoch in range(epochs):
        losses = []
        for (batch,) in loader:
            # Minimise reconstruction loss to learn compressed behavioural representations.
            batch = batch.to(device)
            optimiser.zero_grad()
            recon = model(batch)
            loss = criterion(recon, batch)
            loss.backward()
            optimiser.step()
            losses.append(loss.item())
        if (epoch + 1) % 10 == 0:
            logging.info("Autoencoder epoch %d/%d loss %.4f", epoch + 1, epochs, float(np.mean(losses)))

    model.eval()
    with torch.no_grad():
        tensors = torch.tensor(features.values, dtype=torch.float32).to(device)
        embeddings = model.encode(tensors).cpu().numpy()
    return model, embeddings


def run_clustering(
    embeddings: np.ndarray,
    min_clusters: int = CLUSTER_MIN,
    max_clusters: int = CLUSTER_MAX,
) -> Tuple[np.ndarray, Dict[int, float]]:
    """Search for the optimal number of clusters using silhouette scores."""
    scores = {}
    best_score = -np.inf
    best_n = 3
    for n in range(min_clusters, max_clusters + 1):
        if n >= embeddings.shape[0]:
            break
        kmeans = KMeans(n_clusters=n, random_state=RANDOM_STATE)
        labels = kmeans.fit_predict(embeddings)
        if len(np.unique(labels)) < 2:
            continue
        score = metrics.silhouette_score(embeddings, labels)
        scores[n] = score
        if score > best_score:
            best_score = score
            best_n = n
    chosen_clusters = 3 if 3 in scores else best_n
    logging.info("Selected %d clusters (silhouette %.3f)", chosen_clusters, scores.get(chosen_clusters, np.nan))
    final_model = KMeans(n_clusters=chosen_clusters, random_state=RANDOM_STATE)
    final_labels = final_model.fit_predict(embeddings)
    return final_labels, scores


def assign_risk_labels(clean_df: pd.DataFrame, cluster_labels: np.ndarray) -> pd.Series:
    """Map numeric clusters to human-readable risk tiers based on symptom burden."""
    risk_df = clean_df.assign(cluster=cluster_labels)
    risk_df["risk_score"] = risk_df[["depression", "anxiety", "panic"]].sum(axis=1)
    cluster_scores = risk_df.groupby("cluster")["risk_score"].mean().sort_values()
    risk_mapping = {}
    ordered = list(cluster_scores.index)
    if len(ordered) == 3:
        risk_mapping[ordered[0]] = "Low"
        risk_mapping[ordered[1]] = "Moderate"
        risk_mapping[ordered[2]] = "High"
    else:
        for idx, cluster_id in enumerate(ordered):
            risk_mapping[cluster_id] = f"Cluster {idx+1}"
    return pd.Series(cluster_labels).map(risk_mapping)


def evaluate_models(
    features: pd.DataFrame,
    clean_df: pd.DataFrame,
    risk_labels: pd.Series,
) -> Dict[str, Dict[str, float]]:
    """Train predictive models for CGPA, depression, and risk group classification."""
    depression = clean_df["depression"].values
    cgpa = clean_df["cgpa_numeric"].values

    indices = np.arange(features.shape[0])
    train_idx, test_idx = train_test_split(
        indices,
        test_size=0.2,
        random_state=RANDOM_STATE,
        stratify=depression,
    )

    X_train = features.iloc[train_idx]
    X_test = features.iloc[test_idx]

    y_dep_train = depression[train_idx]
    y_dep_test = depression[test_idx]

    y_cgpa_train = cgpa[train_idx]
    y_cgpa_test = cgpa[test_idx]

    risk_encoder = LabelEncoder()
    risk_numeric = risk_encoder.fit_transform(risk_labels)
    y_risk_train = risk_numeric[train_idx]
    y_risk_test = risk_numeric[test_idx]

    results: Dict[str, Dict[str, float]] = {}

    regression = LinearRegression()
    regression.fit(X_train, y_cgpa_train)
    cgpa_pred = regression.predict(X_test)
    results["linear_regression"] = {
        "mse": float(mean_squared_error(y_cgpa_test, cgpa_pred)),
        "r2": float(r2_score(y_cgpa_test, cgpa_pred)),
        "intercept": float(regression.intercept_),
        "coefficients": {
            feature: float(weight) for feature, weight in zip(features.columns, regression.coef_)
        },
    }

    nb = GaussianNB()
    nb.fit(X_train, y_dep_train)
    dep_pred = nb.predict(X_test)
    nb_cm = confusion_matrix(y_dep_test, dep_pred)
    nb_report = classification_report(
        y_dep_test,
        dep_pred,
        target_names=["No Depression", "Depression"],
        output_dict=True,
        zero_division=0,
    )
    results["naive_bayes"] = {
        "accuracy": float(metrics.accuracy_score(y_dep_test, dep_pred)),
        "f1_macro": float(metrics.f1_score(y_dep_test, dep_pred, average="macro")),
        "confusion_matrix": nb_cm.tolist(),
        "classification_report": nb_report,
        "class_prior": nb.class_prior_.tolist() if hasattr(nb, "class_prior_") else None,
    }

    rf = RandomForestClassifier(**RF_PARAMS)
    rf.fit(X_train, y_risk_train)
    risk_pred = rf.predict(X_test)
    rf_cm = confusion_matrix(y_risk_test, risk_pred)
    rf_report = classification_report(
        y_risk_test,
        risk_pred,
        labels=np.arange(len(risk_encoder.classes_)),
        target_names=list(risk_encoder.classes_),
        output_dict=True,
        zero_division=0,
    )
    results["random_forest"] = {
        "accuracy": float(metrics.accuracy_score(y_risk_test, risk_pred)),
        "f1_macro": float(metrics.f1_score(y_risk_test, risk_pred, average="macro")),
        "confusion_matrix": rf_cm.tolist(),
        "classification_report": rf_report,
        "feature_importances": {
            feature: float(importance)
            for feature, importance in zip(features.columns, rf.feature_importances_)
        },
    }

    logging.info("Random Forest confusion matrix:\n%s", rf_cm)
    logging.info(
        "Random Forest classification report:\n%s",
        classification_report(
            y_risk_test,
            risk_pred,
            labels=np.arange(len(risk_encoder.classes_)),
            target_names=list(risk_encoder.classes_),
            zero_division=0,
        ),
    )
    return results


def run_statistical_tests(clean_df: pd.DataFrame, risk_labels: pd.Series) -> Dict[str, Dict[str, float]]:
    """Compute inferential tests tying cluster risk levels back to demographics and CGPA."""
    stats_results: Dict[str, Dict[str, float]] = {}
    merged = clean_df.copy()
    merged["risk_label"] = risk_labels.values

    groups = [group["cgpa_numeric"].values for _, group in merged.groupby("risk_label") if len(group) > 1]
    if len(groups) >= 2:
        f_stat, p_val = stats.f_oneway(*groups)
        stats_results["anova_cgpa"] = {"f_stat": float(f_stat), "p_value": float(p_val)}

    contingency = pd.crosstab(merged["risk_label"], merged["gender"])
    if contingency.shape[0] > 1 and contingency.shape[1] > 1:
        chi2, p, _, _ = stats.chi2_contingency(contingency)
        stats_results["chi_square_gender"] = {"chi2": float(chi2), "p_value": float(p)}

    high = merged[merged["risk_label"] == "High"]["age"].dropna()
    low = merged[merged["risk_label"] == "Low"]["age"].dropna()
    if len(high) > 1 and len(low) > 1:
        t_stat, p_val = stats.ttest_ind(high, low, equal_var=False)
        stats_results["t_test_age_high_low"] = {"t_stat": float(t_stat), "p_value": float(p_val)}

    return stats_results


def create_visualisations(
    embeddings: np.ndarray,
    risk_labels: pd.Series,
    clean_df: pd.DataFrame,
    output_dir: Path,
) -> List[str]:
    """Generate PCA, t-SNE, and box plots to illustrate cluster structure and traits."""
    output_dir.mkdir(parents=True, exist_ok=True)
    saved_files: List[str] = []

    risk_categories = pd.Categorical(risk_labels)
    risk_codes = risk_categories.codes

    pca = PCA(n_components=2, random_state=RANDOM_STATE)
    pca_coords = pca.fit_transform(embeddings)
    pca_df = pd.DataFrame(pca_coords, columns=["PC1", "PC2"])
    pca_df["risk_code"] = risk_codes
    cmap = plt.get_cmap("viridis")
    ax = pca_df.plot.scatter(
        x="PC1",
        y="PC2",
        c="risk_code",
        colormap="viridis",
        colorbar=True,
        title="PCA of SSL Embeddings",
    )
    handles = [
        plt.Line2D([0], [0], marker="o", linestyle="", color=cmap(ax.collections[0].norm(code)))
        for code in range(len(risk_categories.categories))
    ]
    ax.legend(handles, list(risk_categories.categories), title="Risk Level")
    fig = ax.get_figure()
    pca_path = output_dir / "pca_clusters.png"
    fig.savefig(pca_path, bbox_inches="tight")
    plt.close(fig)
    saved_files.append(str(pca_path))

    tsne = TSNE(n_components=2, random_state=RANDOM_STATE, init="pca", learning_rate="auto")
    tsne_coords = tsne.fit_transform(embeddings)
    tsne_df = pd.DataFrame(tsne_coords, columns=["TSNE1", "TSNE2"])
    tsne_df["risk_code"] = risk_codes
    ax = tsne_df.plot.scatter(
        x="TSNE1",
        y="TSNE2",
        c="risk_code",
        colormap="viridis",
        colorbar=True,
        title="t-SNE of SSL Embeddings",
    )
    handles = [
        plt.Line2D([0], [0], marker="o", linestyle="", color=ax.collections[0].cmap(ax.collections[0].norm(code)))
        for code in range(len(risk_categories.categories))
    ]
    ax.legend(handles, list(risk_categories.categories), title="Risk Level")
    fig = ax.get_figure()
    tsne_path = output_dir / "tsne_clusters.png"
    fig.savefig(tsne_path, bbox_inches="tight")
    plt.close(fig)
    saved_files.append(str(tsne_path))

    box_df = clean_df.assign(risk=risk_labels.values)
    for feature in ["cgpa_numeric", "age", "year_numeric"]:
        ax = box_df.boxplot(column=feature, by="risk", figsize=(6, 4))
        ax.set_title(f"{feature} by Risk Group")
        ax.set_ylabel(feature)
        fig = ax.get_figure()
        fig.suptitle("")
        plot_path = output_dir / f"boxplot_{feature}.png"
        fig.savefig(plot_path, bbox_inches="tight")
        plt.close(fig)
        saved_files.append(str(plot_path))

    return saved_files


def collect_model_properties(embedding_dim: int, processed_df: pd.DataFrame) -> Dict[str, object]:
    """Consolidate configuration metadata for downstream auditing and reporting."""
    return {
        "random_state": RANDOM_STATE,
        "data": {
            "records": int(processed_df.shape[0]),
            "feature_count": int(processed_df.shape[1]),
            "feature_names": processed_df.columns.tolist(),
        },
        "preprocessing": {
            "numeric_features": ["age", "year_numeric", "cgpa_numeric"],
            "categorical_features": ["gender", "course", "marital_status"],
            "binary_features": ["depression", "anxiety", "panic", "specialist"],
            "scaler": "StandardScaler",
            "encoder": "OneHotEncoder(handle_unknown='ignore')",
        },
        "autoencoder": {
            "embedding_dim": embedding_dim,
            "epochs": AUTOENCODER_EPOCHS,
            "batch_size": AUTOENCODER_BATCH_SIZE,
            "learning_rate": AUTOENCODER_LR,
            "optimizer": "Adam",
            "loss": "MSELoss",
        },
        "clustering": {
            "method": "KMeans",
            "min_clusters": CLUSTER_MIN,
            "max_clusters": CLUSTER_MAX,
            "selection_metric": "silhouette_score",
        },
        "train_test_split": {"test_size": 0.2, "stratify": "depression"},
        "models": {
            "linear_regression": {"library": "sklearn", "target": "cgpa_numeric"},
            "naive_bayes": {"type": "GaussianNB"},
            "random_forest": {
                "params": RF_PARAMS,
                "target": "risk_labels",
            },
        },
    }


def flatten_numeric_metrics(model_results: Dict[str, Dict[str, float]]) -> pd.DataFrame:
    """Extract top-level numeric metrics into a flat table for CSV export."""
    rows: List[Dict[str, float]] = []
    for model, details in model_results.items():
        row: Dict[str, float] = {"model": model}
        for key, value in details.items():
            if isinstance(value, (int, float, np.integer, np.floating)):
                row[key] = float(value)
        rows.append(row)
    return pd.DataFrame(rows)


def export_artifacts(
    output_dir: Path,
    processed_df: pd.DataFrame,
    clean_df: pd.DataFrame,
    risk_labels: pd.Series,
    cluster_labels: np.ndarray,
    embeddings: np.ndarray,
    clustering_scores: Dict[int, float],
    model_results: Dict[str, Dict[str, float]],
    model_properties: Dict[str, object],
    stats_results: Dict[str, Dict[str, float]],
) -> Dict[str, str]:
    """Persist processed artefacts and return their filesystem locations."""
    output_dir.mkdir(parents=True, exist_ok=True)
    artifact_paths: Dict[str, str] = {}

    processed_path = output_dir / "processed_features.csv"
    processed_df.to_csv(processed_path, index=False)
    artifact_paths["processed_features"] = str(processed_path)

    risk_profile = clean_df.copy()
    risk_profile["cluster_id"] = cluster_labels
    risk_profile["risk_label"] = risk_labels.values
    risk_profile["risk_score"] = risk_profile[["depression", "anxiety", "panic"]].sum(axis=1)
    risk_profile_path = output_dir / "student_risk_profiles.csv"
    risk_profile.to_csv(risk_profile_path, index=False)
    artifact_paths["risk_profiles"] = str(risk_profile_path)

    embedding_cols = [f"embedding_{idx+1}" for idx in range(embeddings.shape[1])]
    embedding_df = pd.DataFrame(embeddings, columns=embedding_cols)
    embedding_df["cluster_id"] = cluster_labels
    embedding_df["risk_label"] = risk_labels.values
    embedding_path = output_dir / "ssl_embeddings.csv"
    embedding_df.to_csv(embedding_path, index=False)
    artifact_paths["embeddings"] = str(embedding_path)

    silhouette_df = pd.DataFrame(
        {"n_clusters": list(clustering_scores.keys()), "silhouette_score": list(clustering_scores.values())}
    )
    if not silhouette_df.empty:
        silhouette_path = output_dir / "clustering_scores.csv"
        silhouette_df.to_csv(silhouette_path, index=False)
        artifact_paths["clustering_scores"] = str(silhouette_path)

    metrics_df = flatten_numeric_metrics(model_results)
    if not metrics_df.empty:
        metrics_path = output_dir / "performance_metrics.csv"
        metrics_df.to_csv(metrics_path, index=False)
        artifact_paths["performance_metrics"] = str(metrics_path)

    model_results_path = output_dir / "model_results.json"
    with model_results_path.open("w", encoding="utf-8") as handle:
        json.dump(model_results, handle, indent=2)
    artifact_paths["model_results_json"] = str(model_results_path)

    stats_path = output_dir / "statistical_tests.json"
    with stats_path.open("w", encoding="utf-8") as handle:
        json.dump(stats_results, handle, indent=2)
    artifact_paths["stats_json"] = str(stats_path)

    properties_path = output_dir / "model_properties.json"
    with properties_path.open("w", encoding="utf-8") as handle:
        json.dump(model_properties, handle, indent=2)
    artifact_paths["model_properties"] = str(properties_path)

    return artifact_paths


def write_performance_report(
    output_dir: Path,
    model_results: Dict[str, Dict[str, float]],
    stats_results: Dict[str, Dict[str, float]],
) -> str:
    """Create a human-readable performance summary highlighting key metrics and tests."""
    lines: List[str] = []
    lines.append("Performance Metrics Overview")
    lines.append("=" * 30)
    for model, details in model_results.items():
        lines.append(f"\nModel: {model}")
        lines.append("-" * (7 + len(model)))
        for key, value in details.items():
            if isinstance(value, (int, float, np.integer, np.floating)):
                lines.append(f"{key}: {value:.4f}")
        if "classification_report" in details:
            report_df = pd.DataFrame(details["classification_report"]).T
            lines.append("\nClassification Report:")
            lines.append(report_df.to_string(float_format=lambda x: f"{x:.4f}"))
        if "confusion_matrix" in details:
            cm_df = pd.DataFrame(details["confusion_matrix"])
            lines.append("\nConfusion Matrix:")
            lines.append(cm_df.to_string())
        if "coefficients" in details:
            coef_df = pd.DataFrame(
                {"feature": list(details["coefficients"].keys()), "weight": list(details["coefficients"].values())}
            ).sort_values(by="weight", key=lambda col: col.abs(), ascending=False)
            lines.append("\nTop Linear Coefficients:")
            lines.append(coef_df.head(10).to_string(index=False, float_format=lambda x: f"{x:.4f}"))
        if "feature_importances" in details:
            fi_df = pd.DataFrame(
                {
                    "feature": list(details["feature_importances"].keys()),
                    "importance": list(details["feature_importances"].values()),
                }
            ).sort_values(by="importance", ascending=False)
            lines.append("\nRandom Forest Feature Importances:")
            lines.append(fi_df.head(10).to_string(index=False, float_format=lambda x: f"{x:.4f}"))

    if stats_results:
        lines.append("\nStatistical Tests")
        lines.append("-" * 18)
        for test_name, stats_dict in stats_results.items():
            stats_summary = ", ".join(f"{key}={value:.4f}" for key, value in stats_dict.items())
            lines.append(f"{test_name}: {stats_summary}")

    report_path = output_dir / "performance_report.txt"
    with report_path.open("w", encoding="utf-8") as handle:
        handle.write("\n".join(lines))
    return str(report_path)


def build_report(
    output_dir: Path,
    clustering_scores: Dict[int, float],
    model_results: Dict[str, Dict[str, float]],
    stats_results: Dict[str, Dict[str, float]],
    visuals: List[str],
    model_properties: Dict[str, object],
    artifacts: Dict[str, str],
) -> None:
    """Aggregate run outputs into a single JSON manifest for quick inspection."""
    report = {
        "clustering_scores": clustering_scores,
        "model_results": model_results,
        "statistical_tests": stats_results,
        "visualisations": visuals,
        "model_properties": model_properties,
        "artifacts": artifacts,
    }
    report_path = output_dir / "summary.json"
    with report_path.open("w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2)
    logging.info("Saved report to %s", report_path)


def parse_args() -> argparse.Namespace:
    """Configure CLI arguments for data paths, output location, and embedding size."""
    parser = argparse.ArgumentParser(description="Cluster-Based Profiling of Student Mental-Health Risk Groups")
    parser.add_argument(
        "--data",
        nargs="+",
        default=["Student Mental health_1.csv", "Student Mental health_2.csv"],
        help="Paths to CSV files containing the survey data",
    )
    parser.add_argument("--output", default="outputs", help="Directory for generated artefacts")
    parser.add_argument("--embedding-dim", type=int, default=8, help="Dimensionality of the autoencoder bottleneck")
    return parser.parse_args()


def main() -> None:
    """Execute the full pipeline from ingestion through reporting."""
    args = parse_args()
    data_paths = [Path(p).expanduser().resolve() for p in args.data]
    df = load_datasets(data_paths)
    processed_df, clean_df = preprocess_raw(df)

    feature_columns = [col for col in processed_df.columns if col != "cgpa_numeric"]
    modelling_features = processed_df[feature_columns]

    _, embeddings = train_autoencoder(processed_df, embedding_dim=args.embedding_dim)

    cluster_labels, clustering_scores = run_clustering(embeddings)
    risk_labels = assign_risk_labels(clean_df, cluster_labels)

    model_results = evaluate_models(modelling_features, clean_df, risk_labels)
    stats_results = run_statistical_tests(clean_df, risk_labels)
    model_properties = collect_model_properties(args.embedding_dim, processed_df)

    output_dir = Path(args.output).resolve()
    visual_paths = create_visualisations(embeddings, risk_labels, clean_df, output_dir)
    artifact_paths = export_artifacts(
        output_dir,
        processed_df,
        clean_df,
        risk_labels,
        cluster_labels,
        embeddings,
        clustering_scores,
        model_results,
        model_properties,
        stats_results,
    )
    performance_report_path = write_performance_report(output_dir, model_results, stats_results)
    artifact_paths["performance_report"] = performance_report_path
    artifact_paths["visualisations"] = visual_paths

    build_report(
        output_dir,
        clustering_scores,
        model_results,
        stats_results,
        visual_paths,
        model_properties,
        artifact_paths,
    )

    logging.info("Pipeline completed successfully. Artefacts stored in %s", output_dir)


if __name__ == "__main__":
    main()
