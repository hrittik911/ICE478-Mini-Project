# Cluster-Based Profiling of Student Mental-Health Risk Groups

## Overview
This project ingests two Kaggle survey exports, engineers consistent student wellness features, learns self-supervised embeddings via an autoencoder, clusters students into mental-health risk tiers, and validates results with predictive models and statistical tests. All artefacts are written to the `outputs` directory for downstream reporting.

## Prerequisites
- Windows, macOS, or Linux with Python 3.10+
- 8 GB RAM (minimum) for training the autoencoder and running t-SNE
- Git (optional) for version control
- The CSV files `Student Mental health_1.csv` and `Student Mental health_2.csv` stored in the project root

## Environment Setup
1. Create a virtual environment (recommended):
   ```bash
   python -m venv .venv
   .venv\Scripts\activate   # Windows
   source .venv/bin/activate  # macOS/Linux
   ```
2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Running the Pipeline
1. Ensure the CSV files are located in the project directory.
2. From the activated environment, run:
   ```bash
   python mental_health_pipeline.py --output outputs
   ```
   - Override data paths with `--data path/to/file1.csv path/to/file2.csv` if needed.
   - Adjust the autoencoder size using `--embedding-dim 12` (or another integer) when experimenting.
3. Monitor the console for training loss, silhouette scores, and model diagnostics.

## Generated Artefacts
All artefacts are written (or refreshed) inside `outputs/`:
- `processed_features.csv` – scaled, encoded feature matrix
- `ssl_embeddings.csv` – autoencoder embeddings with cluster and risk labels
- `student_risk_profiles.csv` – cleaned student records with risk tier assignments
- `clustering_scores.csv` – silhouette score sweep for clusters 2–6
- `performance_metrics.csv` and `model_results.json` – regression/classification metrics
- `statistical_tests.json` – ANOVA, Chi-square, and Welch t-test outputs
- `model_properties.json` – experiment configuration details
- `performance_report.txt` and `report.txt` – narrative summaries of results
- PCA, t-SNE, and box plot images for visual inspection

## Code Walkthrough
- `load_datasets` – merges multiple CSVs while logging file provenance.
- `preprocess_raw` – standardises text, converts CGPA ranges to numeric midpoints, imputes gaps, and applies scaling plus one-hot encoding.
- `train_autoencoder` – trains a PyTorch autoencoder (configurable embedding size) to learn latent structures.
- `run_clustering` – sweeps K-Means cluster counts, records silhouette scores, and fits the selected clusterer.
- `assign_risk_labels` – orders clusters by composite symptom intensity and maps them to Low/Moderate/High tiers.
- `evaluate_models` – trains linear regression, Gaussian Naive Bayes, and random forest models, capturing detailed metrics and reports.
- `run_statistical_tests` – executes ANOVA, Chi-square, and Welch t-tests to validate cluster distinctiveness.
- `create_visualisations` – exports PCA, t-SNE, and feature distribution plots with consistent legends.
- `export_artifacts` and `write_performance_report` – persist data tables, configuration metadata, and formatted narratives.
- `build_report` – collates artefact paths and metrics into `summary.json` for quick reference.

## Troubleshooting
- `ModuleNotFoundError`: Confirm the virtual environment is activated and dependencies are installed.
- GPU availability: The autoencoder automatically falls back to CPU; training time may increase without a GPU.
- Perfect Naive Bayes accuracy: Re-run with cross-validation or feature ablation to rule out data leakage in customised experiments.
- Memory errors during t-SNE: Increase system swap or disable t-SNE generation in `create_visualisations` for large datasets.

## Next Steps
Consider adding k-fold evaluation, richer lifestyle variables, or anonymisation layers before deploying insights to production systems.
